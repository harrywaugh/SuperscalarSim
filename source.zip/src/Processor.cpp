#include "Processor.h"

using namespace std;

// Processor Constructor
Processor::Processor()  
{
    PC = 0;
}

// Processor Destructor
Processor::~Processor()  
{
}

// Increment the program counter
void Processor::incrementPC()  
{
    PC++;
}

// Increment the number of processor cycles
void Processor::incrementCycles()  
{
    cycles++;
}

void Processor::addInstruction(string line)  
{
    // Instantiate Instruction object, and store in instructions list.
    Instruction new_instruction(line);
    instructions.push_back(new_instruction);
}

// Function takes in string and parses function name, and then creates pointer to the first instruction 
void Processor::addFunction(string line) 
{
    int start_index = 0;
    int current_index = 0;
    string fn_name;

    // Colon immediately follows the function name
    while (current_index < line.size() && line.at(current_index) != ':')
    {
        current_index++;
    }

    // Store name, and then add <function name, pointer to first instruction> to the map
    fn_name = line.substr(start_index, current_index - start_index);
    fn_map.insert(pair<string, int>(fn_name, instructions.size()));
}

/// Function takes in string and parses variable
void Processor::addVariable(string line)
{
    int start_index = 1;
    int current_index = 1;
    string var_name;
    int value;
    // Split string around white space
    while (current_index < line.size() && line.at(current_index) != ' ')  
    {
        current_index++;
    }
    // Store variable label
    var_name = line.substr(start_index, current_index - start_index);
    current_index++;
    // Store variable value
    value = stoi(line.substr(current_index));

    // Put value in memory, and store <label, pointer to mem> in HashMap
    main_memory[free_mem_pointer] = value;
    var_map.insert(pair<string, int>(var_name, free_mem_pointer++));

}

void Processor::addArray(string line)  
{
    int start_index = 1;
    int current_index = 1;
    string arr_name;
    int length;

    // Split string around white space and store variable name
    while (current_index < line.size() && line.at(current_index) != ' ')
        current_index++;
    arr_name = line.substr(start_index, current_index - start_index);
    cout << "Array Name " << arr_name << endl;

    // Split string around white space and store variable length
    current_index++;
    start_index = current_index;
    while (current_index < line.size() && line.at(current_index) != ' ')
        current_index++;
    length = stoi(line.substr(start_index, current_index - start_index));

    // Split string around white space and store array values
    uint32_t *arr_pointer = &main_memory[free_mem_pointer];
    for (int i = 0; i < length; i++)
    {
        current_index++;
        start_index = current_index;
        while (current_index < line.size() && line.at(current_index) != ' ')
            current_index++;
        main_memory[free_mem_pointer++] = stoi(line.substr(start_index, current_index - start_index));
    }
    arr_map.insert(pair<string, uint32_t*>(arr_name, arr_pointer));
}

// Simulate the program on the processor
void Processor::run_program()  
{   
    // Create variable to store current instruction, set program counter to point at main function
    Instruction current_instruction;
    PC = fn_map.at("main");

    // While register exit pin is 0
    while ( registers[31] == 0 )  
    {
        // Print prcoessor state, and wait for 'Enter' keypress
#ifdef DEBUG
        debug_processor();
        getchar();
#endif

        // Fetch stage
        current_instruction = fetch_instruction();
        incrementCycles();

        // Decode and Execute Stages
        incrementCycles();
        decode_and_execute_instruction(current_instruction);
        incrementCycles();

        //Increment program counter
        incrementPC();
        
    }

    // Print prcoessor state and exit
#ifdef DEBUG
    PC = -1;
    debug_processor();
    cout << "Program Result=" << registers[16] << endl;
#endif
    cout << registers[16];
}

// Get the Instruction represented by the program counter
Instruction Processor::fetch_instruction()  {
    return instructions.at(PC);
}

// If statements identify the correct operation, and then execute it.
void Processor::decode_and_execute_instruction(Instruction current_instruction)  {

    switch (string_to_op_map[current_instruction.opcode]) {
        case LI:
            registers[register_map.at(current_instruction.operand0)] = stoi(current_instruction.operand1);
            break;
        case EXIT:
            registers[31] = 1;
            break;
        case J:
            PC = fn_map.at(current_instruction.operand0) - 1;
            break;
        case BEQ:
            if (registers[register_map.at(current_instruction.operand0)] ==
                registers[register_map.at(current_instruction.operand1)])
                PC += stoi(current_instruction.operand2) - 1;
            break;
        case BLT:
            if (registers[register_map.at(current_instruction.operand0)] <
                registers[register_map.at(current_instruction.operand1)])
                PC += stoi(current_instruction.operand2) - 1;
            break;
        case ADD:
            registers[register_map.at(current_instruction.operand0)] =
                registers[register_map.at(current_instruction.operand1)] + registers[register_map.at(current_instruction.operand2)];
            break;
        case  ADDI:
            registers[register_map.at(current_instruction.operand0)] =
                registers[register_map.at(current_instruction.operand1)] + stoi(current_instruction.operand2);
            break;
        case SUB:
            registers[register_map.at(current_instruction.operand0)] =
                registers[register_map.at(current_instruction.operand1)] - registers[register_map.at(current_instruction.operand2)];
            break;
        case SUBI:
            registers[register_map.at(current_instruction.operand0)] =
                registers[register_map.at(current_instruction.operand1)] - stoi(current_instruction.operand2);
            break;
        case MUL:
            registers[register_map.at(current_instruction.operand0)] =
                registers[register_map.at(current_instruction.operand1)] * registers[register_map.at(current_instruction.operand2)];
            break;
        case AND:
            registers[register_map.at(current_instruction.operand0)] =
                registers[register_map.at(current_instruction.operand1)] & registers[register_map.at(current_instruction.operand2)];
            break;
        case OR:
            registers[register_map.at(current_instruction.operand0)] =
                registers[register_map.at(current_instruction.operand1)] | registers[register_map.at(current_instruction.operand2)];
            break;
        case SLL:
            registers[register_map.at(current_instruction.operand0)] =
                registers[register_map.at(current_instruction.operand1)] << stoi(current_instruction.operand2);
            break;
        case SRL:
            registers[register_map.at(current_instruction.operand0)] =
                registers[register_map.at(current_instruction.operand1)] >> stoi(current_instruction.operand2);
            break;
        case MV:
            registers[register_map.at(current_instruction.operand0)] = registers[register_map.at(current_instruction.operand1)];
            break;
        case LW:
            registers[register_map.at(current_instruction.operand0)] = main_memory[registers[register_map.at(current_instruction.operand2)]];
            break;
        case  LA:
            registers[register_map.at(current_instruction.operand0)] = var_map.at(current_instruction.operand1);
            break;
        case SW:
            main_memory[registers[register_map.at(current_instruction.operand2)]] = registers[register_map.at(current_instruction.operand0)];
            break;
        case NOP:
            break;
    }
}

void Processor::debug_processor()  {
    map<string, int>::iterator it;
    map<string, uint32_t*>::iterator it1;

    cout << "\n\n###################" << endl;
    cout << "PROCESSOR DEBUG LOG: Total Cycles = " << cycles << endl;
    cout << "###################" << endl;

    cout << "\nFunctions : \n" << endl;

    for (it = fn_map.begin(); it != fn_map.end(); it++)
    {
        cout << it->first << " -> " << it->second << endl;
    }

    cout << "\nVariables : \n" << endl;

    for (it = var_map.begin(); it != var_map.end(); it++)
    {
        cout << it->first << " -> Mem + " << it->second << endl;
    }

    cout << "\nArrays : \n" << endl;

    for (it1 = arr_map.begin(); it1 != arr_map.end(); it1++)
    {
        cout << it1->first << "[] -> Mem + " << it1->second - &main_memory[0] << endl;
    }

    cout << "\nInstructions : \n" << endl;

    for (int i = 0; i < instructions.size(); i++)  {
        cout << "\t";
        cout << i << ". " << instructions.at(i).to_string(); 
        if (i == PC)
            cout << "  <- PC";
        cout << endl;
    }
    cout << endl;

    cout << "\nRegister Values : \n" << endl;
    for (int j = 0; j < 4; j++)  {
        for (int i = 0; i < 8; i++)  {
            if (j*8+i < 10)  cout << " ";
            cout << j*8+i << ": " << registers[j*8+i] << " ";
        }
        cout << endl;
    }

    cout << "\nMain Memory : \n" << endl;

    for (int j = 0; j < 10; j++)  {
        for (int i = 0; i < 10; i++)  {
            if (j*10+i < 10)  cout << " ";
            cout << j * 10 + i << ": " << main_memory[j * 10 + i] << " ";
        }
        cout << endl;
    }

    cout << endl << endl;
}